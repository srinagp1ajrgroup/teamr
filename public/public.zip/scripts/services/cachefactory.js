xenApp.factory('teamrCache', function ($cacheFactory) {
   return $cacheFactory('myData');
})